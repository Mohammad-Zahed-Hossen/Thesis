# Evidence extraction schema

## Full paper matrix

Use this table for requests phrased as **full extraction**, **paper matrix**, or **thesis relevance**. Retain the exact wording of reported values where accuracy depends on it, with source locations.

| Field | Extraction |
| --- | --- |
| Citation and status | |
| Research problem | |
| Exact failure condition | |
| Main research question | |
| Method | |
| Evidence/confidence signal | |
| Action | Answer / abstain / filter / acquire evidence / mitigate |
| Models | |
| Dataset and split | |
| Baselines | |
| Metrics | |
| Main result | |
| Authors’ stated limitation | |
| Critical interpretation | |
| Relevance to current thesis scope | |
| Reproducibility and compute fit | |

For each field, add a source location when applicable. Use **Not reported in the source** rather than filling a gap by inference.

## Reliability audit

Answer each relevant prompt with: reported evidence and location, cautious interpretation, or **Not reported in the source**.

1. Does the accuracy result establish visual-evidence use, or could language priors explain it?
2. Does lower hallucination coincide with lower coverage or excessive abstention?
3. Is calibration evaluated separately from accuracy?
4. Are ECE, Brier score, NLL, AUROC, risk–coverage curves, or conformal coverage reported where relevant?
5. Is the evaluation deterministic, or does it use a proprietary LLM judge?
6. Is calibration/test leakage possible through shared source images, paired counterfactual examples, or other overlap?
7. Is the method evaluated under missing evidence, cross-modal conflict, or controlled visual degradation?
8. Does it compare with strong, simple baselines?

## Thesis-relevance conclusion

Do not force a binary conclusion. State which element, if any, the paper contributes to the current scope: evidence-grounding evaluation, uncertainty/calibration, selective prediction or abstention, structured visual failure conditions, reproducible evaluation, or a usable baseline. State the missing evidence that must be verified before treating it as a thesis gap.
