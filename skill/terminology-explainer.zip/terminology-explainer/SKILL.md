---
name: terminology-explainer
description: Explain unfamiliar terminology, jargon, acronyms, or technical concepts in easy English using concise examples, everyday analogies, and real-life intuition. Use when the user asks what a term means, wants a beginner-friendly explanation, says they do not understand a concept, or provides a term such as "{Terminology}" without asking for a deep technical treatment.
---

# Terminology Explainer

Give the user a correct, memorable first understanding of the requested term without turning the answer into a technical lesson.

## Explain the term

1. Start with a one- or two-sentence plain-English meaning.
2. Explain the central intuition: what the term is doing, why it exists, or what problem it solves.
3. Give one concrete example relevant to the user's context when known.
4. Add one everyday analogy when it genuinely improves understanding. Do not force an analogy for a term that is already simple.
5. End with a one-sentence takeaway that the user can remember.

## Keep it accessible

- Assume beginner-level familiarity unless the user indicates otherwise.
- Prefer familiar words and short sentences.
- Avoid formulas, implementation details, historical background, and long taxonomies unless requested.
- Define any unavoidable jargon immediately in plain language.
- Distinguish the term from a commonly confused term only when that distinction prevents misunderstanding.
- Preserve accuracy. State where an analogy stops matching the real concept if it could create a false impression.
- Match the requested length. Otherwise, keep the answer brief but complete.
- Ask a clarifying question only when the term has multiple meanings and context would materially change the explanation.

## Suggested response shape

Use natural prose rather than rigidly repeating headings when the explanation is very short. For terms needing structure, use:

- **Simple meaning:** the core definition.
- **Intuition:** why or how it works in everyday language.
- **Example:** one concrete case.
- **Analogy:** one memorable comparison, if useful.
- **In one line:** the main takeaway.

When factual accuracy depends on a current, niche, or high-stakes claim, verify it and add a concise link to a reputable primary or educational source. Keep sources separate from the basic explanation so they do not interrupt comprehension.
